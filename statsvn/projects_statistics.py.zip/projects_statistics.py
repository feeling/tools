__author__ = 'hill'

import os
import subprocess
import platform

def main():
    cur_dir = os.path.split(os.path.realpath(__file__))[0]
    file_object = open('projects.txt')
    for line in file_object:
        print line
        branch = line.split(os.sep)[-1]
        print branch
        sysstr = platform.system()
        if(sysstr =="Windows"):
          print ("Call Windows tasks")
        elif(sysstr == "Linux"):
            print ("Call Linux tasks")
        else:
            print ("Other System tasks")
            doMacJobs(cur_dir,line, branch)

def execute(command):
    process_result = subprocess.Popen(command, shell=True,stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    while True:
        buff = process_result.stdout.readline()
        print buff
        if buff == '' and process_result.poll() != None:
            break

def doMacJobs(cur_dir, strPath, strBranch):
    execute("cd %s" % strPath)
    execute("pwd")
    execute("cd %s" % cur_dir)
    execute("pwd")


if __name__ == '__main__':
    main()
